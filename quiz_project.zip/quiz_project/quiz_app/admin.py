from django import forms
from django.contrib import admin
from .models import Blog, Quiz, Question, Video

admin.site.register(Quiz)
admin.site.register(Question)
admin.site.register(Video)



class BlogAdminForm(forms.ModelForm):
    class Meta:
        model = Blog
        fields = '__all__'

class BlogAdmin(admin.ModelAdmin):
    form = BlogAdminForm

admin.site.register(Blog, BlogAdmin)