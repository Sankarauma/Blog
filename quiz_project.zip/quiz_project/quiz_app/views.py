from django.shortcuts import get_object_or_404, redirect, render
from .models import Blog, Contact, Question, Quiz, Video

def quiz_list(request):
    quizzes = Quiz.objects.all()
    return render(request, 'quiz_app/quiz_list.html', {'quizzes': quizzes})

def about(request):
    questions = Question.objects.all()
    blogs = Blog.objects.all()
    videos = Video.objects.all()
    return render(request, 'quiz_app/about.html', {'questions': questions ,'blogs': blogs,'videos': videos})

def blog_detail(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    return render(request, 'quiz_app/blog_detail.html', {'blog': blog})

def contact_submit(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        description = request.POST['description']
        contact = Contact(name=name, email=email, mobile=mobile, description=description)
        contact.save()
        return redirect('about')  # Redirect to the about page after submission
    return redirect('about')  # If not a POST request, simply redirect

# def about(request):
#     mcq_questions = Question.objects.all()
#     blogs = Blog.objects.all()
#     videos = Video.objects.all()
#     return render(request, 'quiz_app/about.html', {'mcq_questions': mcq_questions, 'blogs': blogs, 'videos': videos})

def quiz_list(request):
    quiz_questions = Question.objects.all()
    return render(request, 'quiz_app/quiz_list.html', {'quiz_questions': quiz_questions})
