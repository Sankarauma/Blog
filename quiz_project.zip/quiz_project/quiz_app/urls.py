from django.urls import path
from . import views

urlpatterns = [
    path('', views.quiz_list, name='quiz_list'),
    path('about/', views.about, name='about'),
    path('blog/<int:blog_id>/', views.blog_detail, name='blog_detail'),
    path('contact/submit/', views.contact_submit, name='contact_submit'),
    path('quiz/', views.quiz_list, name='quiz-list'),
]
