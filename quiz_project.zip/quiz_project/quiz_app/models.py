from django.db import models

class Quiz(models.Model):
    title = models.CharField(max_length=100)

    class Meta:
        app_label = 'quiz_app'

    def __str__(self):
        return self.title

class Question(models.Model):
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    text = models.CharField(max_length=200)

    class Meta:
        app_label = 'quiz_app'

    def __str__(self):
        return self.text
    
class Blog(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()

    def __str__(self):
        return self.title
    
class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    mobile = models.CharField(max_length=15)
    description = models.TextField()

    def __str__(self):
        return self.name
    
class Video(models.Model):
    title = models.CharField(max_length=100)
    link = models.URLField()

    def __str__(self):
        return self.title
    

